import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Capacitor, SystemBars, SystemBarsStyle } from '@capacitor/core';
import App from './App.tsx';
import './index.css';


// Canlı OTA Güncelleme Aktarımı: Cihazdaki giriş oturumunu koruyarak en güncel sürümü açar
try {
  const urlObj = new URL(window.location.href);
  const incomingSession = urlObj.searchParams.get('sb_ota_session');
  if (incomingSession) {
    if (!localStorage.getItem('sb_active_auth_session_v1')) {
      localStorage.setItem('sb_active_auth_session_v1', decodeURIComponent(incomingSession));
    }
    urlObj.searchParams.delete('sb_ota_session');
    window.history.replaceState({}, '', urlObj.toString());
  }
} catch {}

const checkAndApplyLiveUpdate = () => {
  try {
    if (localStorage.getItem('sb_force_ota_refresh_v1') === '1') {
      localStorage.removeItem('sb_force_ota_refresh_v1');
      window.location.reload();
    }
  } catch {}
};

if (Capacitor.isNativePlatform()) {
  SystemBars.setStyle({ style: SystemBarsStyle.Dark }).catch(() => {});
  SystemBars.show().catch(() => {});

  checkAndApplyLiveUpdate();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      SystemBars.setStyle({ style: SystemBarsStyle.Dark }).catch(() => {});
      checkAndApplyLiveUpdate();
    }
  });
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
